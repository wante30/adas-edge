/****************************************************************************
** Meta object code from reading C++ file 'tesla_scene_item.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "tesla_scene_item.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tesla_scene_item.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TeslaSceneItem_t {
    QByteArrayData data[23];
    char stringdata0[316];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TeslaSceneItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TeslaSceneItem_t qt_meta_stringdata_TeslaSceneItem = {
    {
QT_MOC_LITERAL(0, 0, 14), // "TeslaSceneItem"
QT_MOC_LITERAL(1, 15, 12), // "boxesChanged"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 16), // "laneStateChanged"
QT_MOC_LITERAL(4, 46, 18), // "displayViewChanged"
QT_MOC_LITERAL(5, 65, 19), // "roadQuadrantChanged"
QT_MOC_LITERAL(6, 85, 13), // "onlineChanged"
QT_MOC_LITERAL(7, 99, 15), // "demoModeChanged"
QT_MOC_LITERAL(8, 115, 16), // "sourceKeyChanged"
QT_MOC_LITERAL(9, 132, 20), // "sourceFrameIdChanged"
QT_MOC_LITERAL(10, 153, 24), // "sourceTimestampNsChanged"
QT_MOC_LITERAL(11, 178, 15), // "sceneFpsChanged"
QT_MOC_LITERAL(12, 194, 13), // "requestUpdate"
QT_MOC_LITERAL(13, 208, 5), // "boxes"
QT_MOC_LITERAL(14, 214, 9), // "laneState"
QT_MOC_LITERAL(15, 224, 11), // "displayView"
QT_MOC_LITERAL(16, 236, 12), // "roadQuadrant"
QT_MOC_LITERAL(17, 249, 6), // "online"
QT_MOC_LITERAL(18, 256, 8), // "demoMode"
QT_MOC_LITERAL(19, 265, 9), // "sourceKey"
QT_MOC_LITERAL(20, 275, 13), // "sourceFrameId"
QT_MOC_LITERAL(21, 289, 17), // "sourceTimestampNs"
QT_MOC_LITERAL(22, 307, 8) // "sceneFps"

    },
    "TeslaSceneItem\0boxesChanged\0\0"
    "laneStateChanged\0displayViewChanged\0"
    "roadQuadrantChanged\0onlineChanged\0"
    "demoModeChanged\0sourceKeyChanged\0"
    "sourceFrameIdChanged\0sourceTimestampNsChanged\0"
    "sceneFpsChanged\0requestUpdate\0boxes\0"
    "laneState\0displayView\0roadQuadrant\0"
    "online\0demoMode\0sourceKey\0sourceFrameId\0"
    "sourceTimestampNs\0sceneFps"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TeslaSceneItem[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
      10,   80, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x06 /* Public */,
       3,    0,   70,    2, 0x06 /* Public */,
       4,    0,   71,    2, 0x06 /* Public */,
       5,    0,   72,    2, 0x06 /* Public */,
       6,    0,   73,    2, 0x06 /* Public */,
       7,    0,   74,    2, 0x06 /* Public */,
       8,    0,   75,    2, 0x06 /* Public */,
       9,    0,   76,    2, 0x06 /* Public */,
      10,    0,   77,    2, 0x06 /* Public */,
      11,    0,   78,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
      12,    0,   79,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void,

 // properties: name, type, flags
      13, QMetaType::QVariantList, 0x00495103,
      14, QMetaType::QVariantMap, 0x00495103,
      15, QMetaType::QString, 0x00495103,
      16, QMetaType::Int, 0x00495103,
      17, QMetaType::Bool, 0x00495103,
      18, QMetaType::Bool, 0x00495103,
      19, QMetaType::QString, 0x00495103,
      20, QMetaType::ULongLong, 0x00495103,
      21, QMetaType::LongLong, 0x00495103,
      22, QMetaType::Double, 0x00495001,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,
       8,
       9,

       0        // eod
};

void TeslaSceneItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TeslaSceneItem *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->boxesChanged(); break;
        case 1: _t->laneStateChanged(); break;
        case 2: _t->displayViewChanged(); break;
        case 3: _t->roadQuadrantChanged(); break;
        case 4: _t->onlineChanged(); break;
        case 5: _t->demoModeChanged(); break;
        case 6: _t->sourceKeyChanged(); break;
        case 7: _t->sourceFrameIdChanged(); break;
        case 8: _t->sourceTimestampNsChanged(); break;
        case 9: _t->sceneFpsChanged(); break;
        case 10: _t->requestUpdate(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::boxesChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::laneStateChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::displayViewChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::roadQuadrantChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::onlineChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::demoModeChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::sourceKeyChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::sourceFrameIdChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::sourceTimestampNsChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (TeslaSceneItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TeslaSceneItem::sceneFpsChanged)) {
                *result = 9;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<TeslaSceneItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QVariantList*>(_v) = _t->boxes(); break;
        case 1: *reinterpret_cast< QVariantMap*>(_v) = _t->laneState(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->displayView(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->roadQuadrant(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->online(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->demoMode(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->sourceKey(); break;
        case 7: *reinterpret_cast< qulonglong*>(_v) = _t->sourceFrameId(); break;
        case 8: *reinterpret_cast< qint64*>(_v) = _t->sourceTimestampNs(); break;
        case 9: *reinterpret_cast< double*>(_v) = _t->sceneFps(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<TeslaSceneItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setBoxes(*reinterpret_cast< QVariantList*>(_v)); break;
        case 1: _t->setLaneState(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 2: _t->setDisplayView(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setRoadQuadrant(*reinterpret_cast< int*>(_v)); break;
        case 4: _t->setOnline(*reinterpret_cast< bool*>(_v)); break;
        case 5: _t->setDemoMode(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setSourceKey(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setSourceFrameId(*reinterpret_cast< qulonglong*>(_v)); break;
        case 8: _t->setSourceTimestampNs(*reinterpret_cast< qint64*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject TeslaSceneItem::staticMetaObject = { {
    &QQuickFramebufferObject::staticMetaObject,
    qt_meta_stringdata_TeslaSceneItem.data,
    qt_meta_data_TeslaSceneItem,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *TeslaSceneItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TeslaSceneItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TeslaSceneItem.stringdata0))
        return static_cast<void*>(this);
    return QQuickFramebufferObject::qt_metacast(_clname);
}

int TeslaSceneItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickFramebufferObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 10;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void TeslaSceneItem::boxesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void TeslaSceneItem::laneStateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void TeslaSceneItem::displayViewChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void TeslaSceneItem::roadQuadrantChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void TeslaSceneItem::onlineChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void TeslaSceneItem::demoModeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void TeslaSceneItem::sourceKeyChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void TeslaSceneItem::sourceFrameIdChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void TeslaSceneItem::sourceTimestampNsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void TeslaSceneItem::sceneFpsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
