/****************************************************************************
** Meta object code from reading C++ file 'video_item.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "video_item.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'video_item.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_VideoItem_t {
    QByteArrayData data[75];
    char stringdata0[1046];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_VideoItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_VideoItem_t qt_meta_stringdata_VideoItem = {
    {
QT_MOC_LITERAL(0, 0, 9), // "VideoItem"
QT_MOC_LITERAL(1, 10, 14), // "metricsChanged"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 14), // "aiBoxesChanged"
QT_MOC_LITERAL(4, 41, 15), // "aiStatusChanged"
QT_MOC_LITERAL(5, 57, 13), // "frameAdvanced"
QT_MOC_LITERAL(6, 71, 24), // "spatialViewActiveChanged"
QT_MOC_LITERAL(7, 96, 21), // "sourceViewportChanged"
QT_MOC_LITERAL(8, 118, 18), // "aiSelectionChanged"
QT_MOC_LITERAL(9, 137, 16), // "qsgTargetChanged"
QT_MOC_LITERAL(10, 154, 18), // "requestFrameUpdate"
QT_MOC_LITERAL(11, 173, 20), // "notifyAiModelChanged"
QT_MOC_LITERAL(12, 194, 18), // "requestModelSwitch"
QT_MOC_LITERAL(13, 213, 9), // "profileId"
QT_MOC_LITERAL(14, 223, 8), // "inputFps"
QT_MOC_LITERAL(15, 232, 11), // "consumedFps"
QT_MOC_LITERAL(16, 244, 8), // "uploadMs"
QT_MOC_LITERAL(17, 253, 11), // "uploadP95Ms"
QT_MOC_LITERAL(18, 265, 16), // "sourceToUploadMs"
QT_MOC_LITERAL(19, 282, 9), // "renderFps"
QT_MOC_LITERAL(20, 292, 10), // "cpuPercent"
QT_MOC_LITERAL(21, 303, 5), // "rssMb"
QT_MOC_LITERAL(22, 309, 14), // "gpuLoadPercent"
QT_MOC_LITERAL(23, 324, 14), // "gpuFrequencyHz"
QT_MOC_LITERAL(24, 339, 7), // "frameId"
QT_MOC_LITERAL(25, 347, 14), // "producedFrames"
QT_MOC_LITERAL(26, 362, 14), // "consumedFrames"
QT_MOC_LITERAL(27, 377, 13), // "droppedFrames"
QT_MOC_LITERAL(28, 391, 8), // "renderer"
QT_MOC_LITERAL(29, 400, 6), // "vendor"
QT_MOC_LITERAL(30, 407, 9), // "glVersion"
QT_MOC_LITERAL(31, 417, 9), // "eglVendor"
QT_MOC_LITERAL(32, 427, 19), // "hardwareAccelerated"
QT_MOC_LITERAL(33, 447, 8), // "aiStatus"
QT_MOC_LITERAL(34, 456, 8), // "aiOnline"
QT_MOC_LITERAL(35, 465, 5), // "aiFps"
QT_MOC_LITERAL(36, 471, 9), // "aiModelId"
QT_MOC_LITERAL(37, 481, 12), // "aiModelState"
QT_MOC_LITERAL(38, 494, 14), // "aiModelMessage"
QT_MOC_LITERAL(39, 509, 14), // "aiModelOptions"
QT_MOC_LITERAL(40, 524, 9), // "aiTraffic"
QT_MOC_LITERAL(41, 534, 13), // "aiDisplayView"
QT_MOC_LITERAL(42, 548, 12), // "aiNavigation"
QT_MOC_LITERAL(43, 561, 16), // "aiNavigationRoad"
QT_MOC_LITERAL(44, 578, 17), // "aiNavigationState"
QT_MOC_LITERAL(45, 596, 21), // "aiNavigationDirection"
QT_MOC_LITERAL(46, 618, 21), // "aiNavigationDistanceM"
QT_MOC_LITERAL(47, 640, 13), // "aiResultAgeMs"
QT_MOC_LITERAL(48, 654, 13), // "aiHazardAgeMs"
QT_MOC_LITERAL(49, 668, 16), // "aiDetectionCount"
QT_MOC_LITERAL(50, 685, 17), // "aiDetectionCounts"
QT_MOC_LITERAL(51, 703, 7), // "aiBoxes"
QT_MOC_LITERAL(52, 711, 15), // "aiHazardDetails"
QT_MOC_LITERAL(53, 727, 9), // "bboxModel"
QT_MOC_LITERAL(54, 737, 9), // "bboxCount"
QT_MOC_LITERAL(55, 747, 9), // "aiHazards"
QT_MOC_LITERAL(56, 757, 14), // "aiRequestsSent"
QT_MOC_LITERAL(57, 772, 17), // "aiResultsReceived"
QT_MOC_LITERAL(58, 790, 10), // "sourceMode"
QT_MOC_LITERAL(59, 801, 12), // "sourceOnline"
QT_MOC_LITERAL(60, 814, 11), // "sourceAgeMs"
QT_MOC_LITERAL(61, 826, 9), // "sourceFps"
QT_MOC_LITERAL(62, 836, 13), // "sourceFrameId"
QT_MOC_LITERAL(63, 850, 14), // "displayFrameId"
QT_MOC_LITERAL(64, 865, 18), // "displayTimestampNs"
QT_MOC_LITERAL(65, 884, 10), // "aiFrameLag"
QT_MOC_LITERAL(66, 895, 20), // "maxTrackPredictionMs"
QT_MOC_LITERAL(67, 916, 17), // "spatialViewActive"
QT_MOC_LITERAL(68, 934, 19), // "sourceDroppedFrames"
QT_MOC_LITERAL(69, 954, 15), // "sourceCrcErrors"
QT_MOC_LITERAL(70, 970, 14), // "npuLoadPercent"
QT_MOC_LITERAL(71, 985, 14), // "sourceViewport"
QT_MOC_LITERAL(72, 1000, 14), // "aiRoadQuadrant"
QT_MOC_LITERAL(73, 1015, 20), // "aiNavigationQuadrant"
QT_MOC_LITERAL(74, 1036, 9) // "qsgTarget"

    },
    "VideoItem\0metricsChanged\0\0aiBoxesChanged\0"
    "aiStatusChanged\0frameAdvanced\0"
    "spatialViewActiveChanged\0sourceViewportChanged\0"
    "aiSelectionChanged\0qsgTargetChanged\0"
    "requestFrameUpdate\0notifyAiModelChanged\0"
    "requestModelSwitch\0profileId\0inputFps\0"
    "consumedFps\0uploadMs\0uploadP95Ms\0"
    "sourceToUploadMs\0renderFps\0cpuPercent\0"
    "rssMb\0gpuLoadPercent\0gpuFrequencyHz\0"
    "frameId\0producedFrames\0consumedFrames\0"
    "droppedFrames\0renderer\0vendor\0glVersion\0"
    "eglVendor\0hardwareAccelerated\0aiStatus\0"
    "aiOnline\0aiFps\0aiModelId\0aiModelState\0"
    "aiModelMessage\0aiModelOptions\0aiTraffic\0"
    "aiDisplayView\0aiNavigation\0aiNavigationRoad\0"
    "aiNavigationState\0aiNavigationDirection\0"
    "aiNavigationDistanceM\0aiResultAgeMs\0"
    "aiHazardAgeMs\0aiDetectionCount\0"
    "aiDetectionCounts\0aiBoxes\0aiHazardDetails\0"
    "bboxModel\0bboxCount\0aiHazards\0"
    "aiRequestsSent\0aiResultsReceived\0"
    "sourceMode\0sourceOnline\0sourceAgeMs\0"
    "sourceFps\0sourceFrameId\0displayFrameId\0"
    "displayTimestampNs\0aiFrameLag\0"
    "maxTrackPredictionMs\0spatialViewActive\0"
    "sourceDroppedFrames\0sourceCrcErrors\0"
    "npuLoadPercent\0sourceViewport\0"
    "aiRoadQuadrant\0aiNavigationQuadrant\0"
    "qsgTarget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_VideoItem[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
      61,   82, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x06 /* Public */,
       3,    0,   70,    2, 0x06 /* Public */,
       4,    0,   71,    2, 0x06 /* Public */,
       5,    0,   72,    2, 0x06 /* Public */,
       6,    0,   73,    2, 0x06 /* Public */,
       7,    0,   74,    2, 0x06 /* Public */,
       8,    0,   75,    2, 0x06 /* Public */,
       9,    0,   76,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    0,   77,    2, 0x0a /* Public */,
      11,    0,   78,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
      12,    1,   79,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void, QMetaType::QString,   13,

 // properties: name, type, flags
      14, QMetaType::Double, 0x00495001,
      15, QMetaType::Double, 0x00495001,
      16, QMetaType::Double, 0x00495001,
      17, QMetaType::Double, 0x00495001,
      18, QMetaType::Double, 0x00495001,
      19, QMetaType::Double, 0x00495001,
      20, QMetaType::Double, 0x00495001,
      21, QMetaType::Double, 0x00495001,
      22, QMetaType::Double, 0x00495001,
      23, QMetaType::ULongLong, 0x00495001,
      24, QMetaType::ULongLong, 0x00495001,
      25, QMetaType::ULongLong, 0x00495001,
      26, QMetaType::ULongLong, 0x00495001,
      27, QMetaType::ULongLong, 0x00495001,
      28, QMetaType::QString, 0x00495001,
      29, QMetaType::QString, 0x00495001,
      30, QMetaType::QString, 0x00495001,
      31, QMetaType::QString, 0x00495001,
      32, QMetaType::Bool, 0x00495001,
      33, QMetaType::QString, 0x00495001,
      34, QMetaType::Bool, 0x00495001,
      35, QMetaType::Double, 0x00495001,
      36, QMetaType::QString, 0x00495001,
      37, QMetaType::QString, 0x00495001,
      38, QMetaType::QString, 0x00495001,
      39, QMetaType::QVariantList, 0x00495001,
      40, QMetaType::QString, 0x00495001,
      41, QMetaType::QString, 0x00495001,
      42, QMetaType::QString, 0x00495001,
      43, QMetaType::QString, 0x00495001,
      44, QMetaType::QString, 0x00495001,
      45, QMetaType::QString, 0x00495001,
      46, QMetaType::Double, 0x00495001,
      47, QMetaType::Int, 0x00495001,
      48, QMetaType::Int, 0x00495001,
      49, QMetaType::Int, 0x00495001,
      50, QMetaType::QVariantMap, 0x00495001,
      51, QMetaType::QVariantList, 0x00495001,
      52, QMetaType::QVariantList, 0x00495001,
      53, QMetaType::QObjectStar, 0x00095401,
      54, QMetaType::Int, 0x00495001,
      55, QMetaType::QVariantList, 0x00495001,
      56, QMetaType::ULongLong, 0x00495001,
      57, QMetaType::ULongLong, 0x00495001,
      58, QMetaType::QString, 0x00495001,
      59, QMetaType::Bool, 0x00495001,
      60, QMetaType::Double, 0x00495001,
      61, QMetaType::Double, 0x00495001,
      62, QMetaType::ULongLong, 0x00495001,
      63, QMetaType::ULongLong, 0x00495001,
      64, QMetaType::ULongLong, 0x00495001,
      65, QMetaType::Int, 0x00495001,
      66, QMetaType::Int, 0x00495103,
      67, QMetaType::Bool, 0x00495103,
      68, QMetaType::ULongLong, 0x00495001,
      69, QMetaType::ULongLong, 0x00495001,
      70, QMetaType::Double, 0x00495001,
      71, QMetaType::QRectF, 0x00495103,
      72, QMetaType::Int, 0x00495103,
      73, QMetaType::Int, 0x00495103,
      74, QMetaType::QObjectStar, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       2,
       2,
       2,
       2,
       2,
       2,
       2,
       2,
       2,
       2,
       2,
       0,
       0,
       1,
       1,
       1,
       2,
       0,
       1,
       2,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       3,
       3,
       1,
       0,
       4,
       0,
       0,
       0,
       5,
       6,
       6,
       7,

       0        // eod
};

void VideoItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<VideoItem *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->metricsChanged(); break;
        case 1: _t->aiBoxesChanged(); break;
        case 2: _t->aiStatusChanged(); break;
        case 3: _t->frameAdvanced(); break;
        case 4: _t->spatialViewActiveChanged(); break;
        case 5: _t->sourceViewportChanged(); break;
        case 6: _t->aiSelectionChanged(); break;
        case 7: _t->qsgTargetChanged(); break;
        case 8: _t->requestFrameUpdate(); break;
        case 9: _t->notifyAiModelChanged(); break;
        case 10: _t->requestModelSwitch((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::metricsChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::aiBoxesChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::aiStatusChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::frameAdvanced)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::spatialViewActiveChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::sourceViewportChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::aiSelectionChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (VideoItem::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VideoItem::qsgTargetChanged)) {
                *result = 7;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<VideoItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = _t->inputFps(); break;
        case 1: *reinterpret_cast< double*>(_v) = _t->consumedFps(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->uploadMs(); break;
        case 3: *reinterpret_cast< double*>(_v) = _t->uploadP95Ms(); break;
        case 4: *reinterpret_cast< double*>(_v) = _t->sourceToUploadMs(); break;
        case 5: *reinterpret_cast< double*>(_v) = _t->renderFps(); break;
        case 6: *reinterpret_cast< double*>(_v) = _t->cpuPercent(); break;
        case 7: *reinterpret_cast< double*>(_v) = _t->rssMb(); break;
        case 8: *reinterpret_cast< double*>(_v) = _t->gpuLoadPercent(); break;
        case 9: *reinterpret_cast< qulonglong*>(_v) = _t->gpuFrequencyHz(); break;
        case 10: *reinterpret_cast< qulonglong*>(_v) = _t->frameId(); break;
        case 11: *reinterpret_cast< qulonglong*>(_v) = _t->producedFrames(); break;
        case 12: *reinterpret_cast< qulonglong*>(_v) = _t->consumedFrames(); break;
        case 13: *reinterpret_cast< qulonglong*>(_v) = _t->droppedFrames(); break;
        case 14: *reinterpret_cast< QString*>(_v) = _t->renderer(); break;
        case 15: *reinterpret_cast< QString*>(_v) = _t->vendor(); break;
        case 16: *reinterpret_cast< QString*>(_v) = _t->glVersion(); break;
        case 17: *reinterpret_cast< QString*>(_v) = _t->eglVendor(); break;
        case 18: *reinterpret_cast< bool*>(_v) = _t->hardwareAccelerated(); break;
        case 19: *reinterpret_cast< QString*>(_v) = _t->aiStatus(); break;
        case 20: *reinterpret_cast< bool*>(_v) = _t->aiOnline(); break;
        case 21: *reinterpret_cast< double*>(_v) = _t->aiFps(); break;
        case 22: *reinterpret_cast< QString*>(_v) = _t->aiModelId(); break;
        case 23: *reinterpret_cast< QString*>(_v) = _t->aiModelState(); break;
        case 24: *reinterpret_cast< QString*>(_v) = _t->aiModelMessage(); break;
        case 25: *reinterpret_cast< QVariantList*>(_v) = _t->aiModelOptions(); break;
        case 26: *reinterpret_cast< QString*>(_v) = _t->aiTraffic(); break;
        case 27: *reinterpret_cast< QString*>(_v) = _t->aiDisplayView(); break;
        case 28: *reinterpret_cast< QString*>(_v) = _t->aiNavigation(); break;
        case 29: *reinterpret_cast< QString*>(_v) = _t->aiNavigationRoad(); break;
        case 30: *reinterpret_cast< QString*>(_v) = _t->aiNavigationState(); break;
        case 31: *reinterpret_cast< QString*>(_v) = _t->aiNavigationDirection(); break;
        case 32: *reinterpret_cast< double*>(_v) = _t->aiNavigationDistanceM(); break;
        case 33: *reinterpret_cast< int*>(_v) = _t->aiResultAgeMs(); break;
        case 34: *reinterpret_cast< int*>(_v) = _t->aiHazardAgeMs(); break;
        case 35: *reinterpret_cast< int*>(_v) = _t->aiDetectionCount(); break;
        case 36: *reinterpret_cast< QVariantMap*>(_v) = _t->aiDetectionCounts(); break;
        case 37: *reinterpret_cast< QVariantList*>(_v) = _t->aiBoxes(); break;
        case 38: *reinterpret_cast< QVariantList*>(_v) = _t->aiHazardDetails(); break;
        case 39: *reinterpret_cast< QObject**>(_v) = _t->bboxModelObject(); break;
        case 40: *reinterpret_cast< int*>(_v) = _t->bboxCount(); break;
        case 41: *reinterpret_cast< QVariantList*>(_v) = _t->aiHazards(); break;
        case 42: *reinterpret_cast< qulonglong*>(_v) = _t->aiRequestsSent(); break;
        case 43: *reinterpret_cast< qulonglong*>(_v) = _t->aiResultsReceived(); break;
        case 44: *reinterpret_cast< QString*>(_v) = _t->sourceMode(); break;
        case 45: *reinterpret_cast< bool*>(_v) = _t->sourceOnline(); break;
        case 46: *reinterpret_cast< double*>(_v) = _t->sourceAgeMs(); break;
        case 47: *reinterpret_cast< double*>(_v) = _t->sourceFps(); break;
        case 48: *reinterpret_cast< qulonglong*>(_v) = _t->sourceFrameId(); break;
        case 49: *reinterpret_cast< qulonglong*>(_v) = _t->displayFrameId(); break;
        case 50: *reinterpret_cast< qulonglong*>(_v) = _t->displayTimestampNs(); break;
        case 51: *reinterpret_cast< int*>(_v) = _t->aiFrameLag(); break;
        case 52: *reinterpret_cast< int*>(_v) = _t->maxTrackPredictionMs(); break;
        case 53: *reinterpret_cast< bool*>(_v) = _t->spatialViewActive(); break;
        case 54: *reinterpret_cast< qulonglong*>(_v) = _t->sourceDroppedFrames(); break;
        case 55: *reinterpret_cast< qulonglong*>(_v) = _t->sourceCrcErrors(); break;
        case 56: *reinterpret_cast< double*>(_v) = _t->npuLoadPercent(); break;
        case 57: *reinterpret_cast< QRectF*>(_v) = _t->sourceViewport(); break;
        case 58: *reinterpret_cast< int*>(_v) = _t->aiRoadQuadrant(); break;
        case 59: *reinterpret_cast< int*>(_v) = _t->aiNavigationQuadrant(); break;
        case 60: *reinterpret_cast< QObject**>(_v) = _t->qsgTarget(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<VideoItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 52: _t->setMaxTrackPredictionMs(*reinterpret_cast< int*>(_v)); break;
        case 53: _t->setSpatialViewActive(*reinterpret_cast< bool*>(_v)); break;
        case 57: _t->setSourceViewport(*reinterpret_cast< QRectF*>(_v)); break;
        case 58: _t->setAiRoadQuadrant(*reinterpret_cast< int*>(_v)); break;
        case 59: _t->setAiNavigationQuadrant(*reinterpret_cast< int*>(_v)); break;
        case 60: _t->setQsgTarget(*reinterpret_cast< QObject**>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject VideoItem::staticMetaObject = { {
    &QQuickFramebufferObject::staticMetaObject,
    qt_meta_stringdata_VideoItem.data,
    qt_meta_data_VideoItem,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *VideoItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *VideoItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_VideoItem.stringdata0))
        return static_cast<void*>(this);
    return QQuickFramebufferObject::qt_metacast(_clname);
}

int VideoItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickFramebufferObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 61;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 61;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 61;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 61;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 61;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 61;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void VideoItem::metricsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void VideoItem::aiBoxesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void VideoItem::aiStatusChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void VideoItem::frameAdvanced()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void VideoItem::spatialViewActiveChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void VideoItem::sourceViewportChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void VideoItem::aiSelectionChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void VideoItem::qsgTargetChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
