/****************************************************************************
** Meta object code from reading C++ file 'pcie_isp_control.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "pcie_isp_control.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'pcie_isp_control.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PcieIspControl_t {
    QByteArrayData data[15];
    char stringdata0[131];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PcieIspControl_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PcieIspControl_t qt_meta_stringdata_PcieIspControl = {
    {
QT_MOC_LITERAL(0, 0, 14), // "PcieIspControl"
QT_MOC_LITERAL(1, 15, 12), // "replyArrived"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 7), // "summary"
QT_MOC_LITERAL(4, 37, 6), // "status"
QT_MOC_LITERAL(5, 44, 4), // "mode"
QT_MOC_LITERAL(6, 49, 5), // "query"
QT_MOC_LITERAL(7, 55, 13), // "applyIspReset"
QT_MOC_LITERAL(8, 69, 14), // "applyIspMaster"
QT_MOC_LITERAL(9, 84, 7), // "enabled"
QT_MOC_LITERAL(10, 92, 9), // "applyAlgo"
QT_MOC_LITERAL(11, 102, 6), // "dehaze"
QT_MOC_LITERAL(12, 109, 8), // "gaussian"
QT_MOC_LITERAL(13, 118, 6), // "median"
QT_MOC_LITERAL(14, 125, 5) // "sobel"

    },
    "PcieIspControl\0replyArrived\0\0summary\0"
    "status\0mode\0query\0applyIspReset\0"
    "applyIspMaster\0enabled\0applyAlgo\0"
    "dehaze\0gaussian\0median\0sobel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PcieIspControl[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,   39,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
       6,    0,   46,    2, 0x02 /* Public */,
       7,    0,   47,    2, 0x02 /* Public */,
       8,    1,   48,    2, 0x02 /* Public */,
      10,    4,   51,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,    3,    4,    5,

 // methods: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,   11,   12,   13,   14,

       0        // eod
};

void PcieIspControl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PcieIspControl *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->replyArrived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 1: _t->query(); break;
        case 2: _t->applyIspReset(); break;
        case 3: _t->applyIspMaster((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->applyAlgo((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PcieIspControl::*)(const QString & , const QString & , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PcieIspControl::replyArrived)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject PcieIspControl::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_PcieIspControl.data,
    qt_meta_data_PcieIspControl,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PcieIspControl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PcieIspControl::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PcieIspControl.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int PcieIspControl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void PcieIspControl::replyArrived(const QString & _t1, const QString & _t2, const QString & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
