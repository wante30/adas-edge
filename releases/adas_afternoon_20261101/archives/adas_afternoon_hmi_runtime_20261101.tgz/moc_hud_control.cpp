/****************************************************************************
** Meta object code from reading C++ file 'hud_control.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "hud_control.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'hud_control.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_HudControl_t {
    QByteArrayData data[35];
    char stringdata0[401];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_HudControl_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_HudControl_t qt_meta_stringdata_HudControl = {
    {
QT_MOC_LITERAL(0, 0, 10), // "HudControl"
QT_MOC_LITERAL(1, 11, 13), // "statusChanged"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 11), // "readPending"
QT_MOC_LITERAL(4, 38, 8), // "checkAge"
QT_MOC_LITERAL(5, 47, 14), // "sendPerception"
QT_MOC_LITERAL(6, 62, 17), // "perception_enable"
QT_MOC_LITERAL(7, 80, 7), // "traffic"
QT_MOC_LITERAL(8, 88, 10), // "pedestrian"
QT_MOC_LITERAL(9, 99, 13), // "static_target"
QT_MOC_LITERAL(10, 113, 9), // "overspeed"
QT_MOC_LITERAL(11, 123, 9), // "lane_left"
QT_MOC_LITERAL(12, 133, 10), // "lane_right"
QT_MOC_LITERAL(13, 144, 11), // "lka_warning"
QT_MOC_LITERAL(14, 156, 11), // "time_enable"
QT_MOC_LITERAL(15, 168, 13), // "legacy_enable"
QT_MOC_LITERAL(16, 182, 12), // "legacy_state"
QT_MOC_LITERAL(17, 195, 14), // "hazard_warning"
QT_MOC_LITERAL(18, 210, 4), // "ping"
QT_MOC_LITERAL(19, 215, 14), // "sendNavigation"
QT_MOC_LITERAL(20, 230, 7), // "enabled"
QT_MOC_LITERAL(21, 238, 9), // "direction"
QT_MOC_LITERAL(22, 248, 9), // "distanceM"
QT_MOC_LITERAL(23, 258, 8), // "queryNav"
QT_MOC_LITERAL(24, 267, 8), // "queryIsp"
QT_MOC_LITERAL(25, 276, 13), // "queryProtocol"
QT_MOC_LITERAL(26, 290, 12), // "bridgeStatus"
QT_MOC_LITERAL(27, 303, 9), // "lastReply"
QT_MOC_LITERAL(28, 313, 12), // "bridgeOnline"
QT_MOC_LITERAL(29, 326, 14), // "lastAppliedSeq"
QT_MOC_LITERAL(30, 341, 9), // "lastError"
QT_MOC_LITERAL(31, 351, 9), // "navStatus"
QT_MOC_LITERAL(32, 361, 9), // "ispStatus"
QT_MOC_LITERAL(33, 371, 15), // "protocolSummary"
QT_MOC_LITERAL(34, 387, 13) // "protocolLines"

    },
    "HudControl\0statusChanged\0\0readPending\0"
    "checkAge\0sendPerception\0perception_enable\0"
    "traffic\0pedestrian\0static_target\0"
    "overspeed\0lane_left\0lane_right\0"
    "lka_warning\0time_enable\0legacy_enable\0"
    "legacy_state\0hazard_warning\0ping\0"
    "sendNavigation\0enabled\0direction\0"
    "distanceM\0queryNav\0queryIsp\0queryProtocol\0"
    "bridgeStatus\0lastReply\0bridgeOnline\0"
    "lastAppliedSeq\0lastError\0navStatus\0"
    "ispStatus\0protocolSummary\0protocolLines"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_HudControl[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       9,  152, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,   70,    2, 0x08 /* Private */,
       4,    0,   71,    2, 0x08 /* Private */,

 // methods: name, argc, parameters, tag, flags
       5,   12,   72,    2, 0x02 /* Public */,
       5,   11,   97,    2, 0x22 /* Public | MethodCloned */,
       5,   10,  120,    2, 0x22 /* Public | MethodCloned */,
      18,    0,  141,    2, 0x02 /* Public */,
      19,    3,  142,    2, 0x02 /* Public */,
      23,    0,  149,    2, 0x02 /* Public */,
      24,    0,  150,    2, 0x02 /* Public */,
      25,    0,  151,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void, QMetaType::Bool, QMetaType::Int, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Bool,    6,    7,    8,    9,   10,   11,   12,   13,   14,   15,   16,   17,
    QMetaType::Void, QMetaType::Bool, QMetaType::Int, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int,    6,    7,    8,    9,   10,   11,   12,   13,   14,   15,   16,
    QMetaType::Void, QMetaType::Bool, QMetaType::Int, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,    6,    7,    8,    9,   10,   11,   12,   13,   14,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString, QMetaType::Int,   20,   21,   22,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      26, QMetaType::QString, 0x00495001,
      27, QMetaType::QString, 0x00495001,
      28, QMetaType::Bool, 0x00495001,
      29, QMetaType::Int, 0x00495001,
      30, QMetaType::Int, 0x00495001,
      31, QMetaType::QString, 0x00495001,
      32, QMetaType::QString, 0x00495001,
      33, QMetaType::QString, 0x00495001,
      34, QMetaType::QVariantList, 0x00495001,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,

       0        // eod
};

void HudControl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<HudControl *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->statusChanged(); break;
        case 1: _t->readPending(); break;
        case 2: _t->checkAge(); break;
        case 3: _t->sendPerception((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])),(*reinterpret_cast< int(*)>(_a[11])),(*reinterpret_cast< bool(*)>(_a[12]))); break;
        case 4: _t->sendPerception((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])),(*reinterpret_cast< int(*)>(_a[11]))); break;
        case 5: _t->sendPerception((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10]))); break;
        case 6: _t->ping(); break;
        case 7: _t->sendNavigation((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 8: _t->queryNav(); break;
        case 9: _t->queryIsp(); break;
        case 10: _t->queryProtocol(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (HudControl::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&HudControl::statusChanged)) {
                *result = 0;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<HudControl *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->bridgeStatus(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->lastReply(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->bridgeOnline(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->lastAppliedSeq(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->lastError(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->navStatus(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->ispStatus(); break;
        case 7: *reinterpret_cast< QString*>(_v) = _t->protocolSummary(); break;
        case 8: *reinterpret_cast< QVariantList*>(_v) = _t->protocolLines(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject HudControl::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_HudControl.data,
    qt_meta_data_HudControl,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *HudControl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HudControl::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_HudControl.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int HudControl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 9;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void HudControl::statusChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
