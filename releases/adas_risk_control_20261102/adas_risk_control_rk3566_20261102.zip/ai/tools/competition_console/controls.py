"""Keyboard/mouse controls shared by native UI and scripted simulation tests."""
from dataclasses import replace

from competition_ai.scenario import Controls, Lane, Maneuver, Mode, Motion


class Controller:
    def __init__(self):
        # The native console opens an intersection scene. Changing the visible
        # mode must not silently turn that known signal-controlled scene off.
        self.controls = Controls(signalized=True)
        self.paused = False
        self.binding = False
        self.overlay = True
        self.diagnostics = False
        self.bev = False

    def key(self, key):
        if isinstance(key,int):
            if key == 27:
                if self.binding:
                    self.binding = False
                    return None
                if self.diagnostics:
                    self.diagnostics = False
                    return None
                if self.bev:
                    self.bev = False
                    return None
                return 'quit'
            if not 0 <= key < 128:
                return None
            key = chr(key)
        key = key.lower()
        lanes = {'1':Lane.LEFT,'2':Lane.STRAIGHT,'3':Lane.RIGHT}
        motions = {'0':Motion.AUTO,'s':Motion.STOP,'g':Motion.GO}
        modes = {'i':Mode.INTERSECTION,'d':Mode.ROAD,'n':Mode.NAVIGATION,'h':Mode.HAZARD}
        requests = {'a':Maneuver.AUTO,'q':Maneuver.CHANGE_LEFT,'e':Maneuver.CHANGE_RIGHT,
                    'j':Maneuver.TURN_LEFT,'l':Maneuver.TURN_RIGHT}
        if key in lanes:
            self.controls = replace(self.controls,lane=lanes[key])
            self.binding = False
        elif key in motions:
            self.controls = replace(self.controls,motion=motions[key])
        elif key in modes:
            self.controls = replace(self.controls,mode=modes[key],request=Maneuver.AUTO)
            self.binding = False
        elif key in requests:
            self.controls = replace(self.controls,request=requests[key])
        elif key == 't':
            if self.controls.mode != Mode.INTERSECTION:
                self.controls = replace(self.controls,signalized=not self.controls.signalized)
            self.binding = False
        elif key == 'v':
            self.overlay = not self.overlay
        elif key == 'f':
            self.diagnostics = not self.diagnostics
        elif key == 'c':
            self.bev = not self.bev
        elif key == ' ':
            self.paused = not self.paused
        elif key == '.':
            self.paused = True
            return 'step'
        elif key == 'b':
            self.binding = not self.binding
            self.bev = False
            self.diagnostics = False
        elif key == 'r':
            self.__init__()
            return 'restart'
        elif key == 'o':
            return 'open'
        return None
