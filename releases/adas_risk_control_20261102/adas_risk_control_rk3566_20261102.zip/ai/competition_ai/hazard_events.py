"""Experimental front-camera events from real, source-timed detections.

Image expansion is a collision cue, not measured lead-car deceleration.
The displayed path is an explicit image-space assumption, not detected lanes.
Vehicle traffic lights never establish a pedestrian signal violation.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import math
import time

import cv2
import numpy as np

from .image_motion import BackgroundMotion, ImageMotion
from .image_tracks import ImageTracker, iou

VEHICLES = {'car', 'truck', 'bus'}
NEAR_OBJECTS = VEHICLES | {'person'}
DEFAULT_PATH = ((.485, .48), (.515, .48), (.63, .88), (.37, .88))
NEAR_OBJECT_HOLD_NS = 1_000_000_000
NEAR_OBJECT_CLEAR_OBSERVATIONS = 4
NEAR_OBJECT_MIN_FOOT = .75
NEAR_VEHICLE_MIN_HEIGHT = .22
NEAR_PERSON_MIN_HEIGHT = .28
NEAR_OBJECT_MIN_AREA = .018


@dataclass(frozen=True)
class HazardObservation:
    timestamp_ns: int | None = None
    events: tuple[dict, ...] = ()
    tracks: tuple[dict, ...] = ()
    path: tuple = DEFAULT_PATH
    motion: ImageMotion = field(default_factory=ImageMotion)
    reason: str = 'disabled'
    lead_id: int | None = None
    sudden_braking: str = 'UNKNOWN_NO_EGO_SPEED_OR_CALIBRATED_RANGE'
    pedestrian_red_violation: str = 'UNKNOWN_NO_ASSOCIATED_PEDESTRIAN_SIGNAL'

    @property
    def pedestrian_hazard(self):
        return any(e['kind'] in ('PEDESTRIAN_IN_PATH', 'PEDESTRIAN_CROSSING_PATH')
                   or (e['kind'] == 'NEAR_OBJECT_IN_PATH' and e.get('target_class') == 'person')
                   for e in self.events)

    @property
    def obstacle_hazard(self):
        return any(e['kind'] in ('FRONT_COLLISION_RISK', 'LEAD_RAPID_CLOSING')
                   or (e['kind'] == 'NEAR_OBJECT_IN_PATH'
                       and e.get('target_class') in VEHICLES)
                   for e in self.events)


def trend(history, index, *, corrected=False):
    data = list(history)
    ts = np.array([(row[0]-data[0][0])/1e9 for row in data])
    values = np.array([row[index]-(row[4] if corrected else 0.) for row in data])
    if len(ts) < 6 or ts[-1] < .5:
        return 0., 0.
    centered = ts-ts.mean()
    slope = float(centered @ (values-values.mean()) / max(float(centered @ centered), 1e-9))
    residual = values-(values.mean()+slope*centered)
    variation = float(np.square(values-values.mean()).sum())
    fit = 1.-float(np.square(residual).sum())/variation if variation > 1e-9 else 0.
    return slope, fit


def paired_red_lamps(frame, box):
    x1, y1, x2, y2 = map(round, box)
    crop = frame[max(0, y1):y2, max(0, x1):x2]
    if crop.shape[0] < 25 or crop.shape[1] < 40:
        return 0.
    crop = cv2.resize(crop, (100, 64))
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    red = ((hsv[:, :, 0] < 12) | (hsv[:, :, 0] > 168)) & (hsv[:, :, 1] > 120) & (hsv[:, :, 2] > 165)
    left, right = float(red[25:51, 5:35].mean()), float(red[25:51, 65:95].mean())
    return min(left, right) if min(left, right) > max(left, right)*.3 else 0.


class HazardEvents:
    def __init__(self, path=DEFAULT_PATH):
        polygon = np.asarray(path, dtype=np.float32)
        if polygon.shape != (4, 2) or not np.isfinite(polygon).all() or (polygon < 0).any() or (polygon > 1).any():
            raise ValueError('Path must contain four finite normalized image points')
        if not cv2.isContourConvex(polygon) or abs(cv2.contourArea(polygon)) < .005:
            raise ValueError('Path must be a convex, nondegenerate polygon')
        self.path = tuple(tuple(float(v) for v in point) for point in polygon)
        self.polygon = polygon
        self.timings = deque(maxlen=3600)
        self.reset()

    def reset(self):
        self.tracker, self.background = ImageTracker(), BackgroundMotion()
        self.last_frame, self.last_ns, self.blocked_until = None, None, 0
        self.confirmations = {}
        self.near_confirmations = {}
        self.near_clear_confirmations = {}
        self.recent_leads = {}
        self.near_events = {}
        self.observation = HazardObservation(path=self.path, reason='warming_up')

    def inside(self, x, y):
        return cv2.pointPolygonTest(self.polygon, (float(x), float(y)), False) >= 0

    def update(self, frame, detections, frame_id, timestamp_ns, *, motion=None):
        if self.last_frame == frame_id and self.last_ns == timestamp_ns:
            return self.observation
        if not isinstance(timestamp_ns, int) or timestamp_ns < 0:
            raise ValueError('Invalid source timestamp')
        if self.last_ns is not None and (timestamp_ns <= self.last_ns or timestamp_ns-self.last_ns > 300_000_000):
            self.reset()
        started = time.perf_counter()
        self.last_frame, self.last_ns = frame_id, timestamp_ns
        motion = motion if motion is not None else self.background.update(frame, detections, timestamp_ns)
        height, width = frame.shape[:2]
        items = []
        riders = [d['bbox'] for d in detections if d['class_name'] in ('motorcycle', 'bicycle')]
        for item in detections:
            name, box = item['class_name'], item['bbox']
            if name not in VEHICLES | {'person'} or item.get('confidence', 0.) < .4:
                continue
            if len(box) != 4 or not all(math.isfinite(v) for v in box):
                continue
            x1, y1, x2, y2 = box
            if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height):
                continue
            # Large shallow bonnet detections and people riding bikes are not
            # evidence of a lead vehicle or a pedestrian on foot.
            if name in VEHICLES and y2 > height*.84 and (x2-x1)/(y2-y1) > 2.7:
                continue
            if name == 'person' and any(iou(box, rider) > .18 for rider in riders):
                continue
            items.append(item)
        tracks = self.tracker.update(items, timestamp_ns, frame.shape, motion)
        if not motion.stable:
            self.blocked_until = timestamp_ns+500_000_000
            self.confirmations.clear()
            for track in self.tracker.tracks.values():
                track.history.clear()
                track.lamp_history.clear()
        trusted = motion.stable and timestamp_ns >= self.blocked_until
        candidates = [t for t in tracks if t.name in VEHICLES and self.inside(t.history[-1][1], t.box[3]/height)] if trusted else []
        lead = max(candidates, key=lambda t: t.box[3], default=None)
        self.recent_leads = {k: ts for k, ts in self.recent_leads.items()
                             if 0 <= timestamp_ns-ts <= 2_000_000_000}
        if lead is not None:
            self.recent_leads[lead.track_id] = timestamp_ns
        events, evidence, active_confirmations, active_near_confirmations = [], [], {}, {}
        current_track_ids = set()
        for track in tracks:
            current_track_ids.add(track.track_id)
            history = list(track.history)
            info = {'id': track.track_id, 'class_name': track.name, 'bbox': track.box,
                    'observations': len(history), 'in_assumed_path': False}
            if history:
                x, foot, size = history[-1][1:4]
                info['in_assumed_path'] = self.inside(x, foot)
            near = False
            if track.name in NEAR_OBJECTS:
                x = (track.box[0] + track.box[2]) / (2 * width)
                foot = track.box[3] / height
                box_width = (track.box[2] - track.box[0]) / width
                box_height = (track.box[3] - track.box[1]) / height
                box_area = box_width * box_height
                min_height = (NEAR_PERSON_MIN_HEIGHT if track.name == 'person'
                              else NEAR_VEHICLE_MIN_HEIGHT)
                near_path = self.inside(x, min(foot, .88))
                near = (near_path and abs(x - .5) <= .13
                        and foot >= NEAR_OBJECT_MIN_FOOT
                        and box_height >= min_height
                        and box_area >= NEAR_OBJECT_MIN_AREA
                        and not (track.name in VEHICLES and box_width / max(box_height, 1e-9) > 2.7))
                if near:
                    self.near_clear_confirmations.pop(track.track_id, None)
                    count = self.near_confirmations.get(track.track_id, 0) + 1
                    active_near_confirmations[track.track_id] = count
                    if count >= 2:
                        severity = ('critical' if foot >= .86 and box_area >= .08
                                    else 'warning')
                        event = {'kind': 'NEAR_OBJECT_IN_PATH', 'track_id': track.track_id,
                                 'bbox': list(track.box), 'target_class': track.name,
                                 'severity': severity,
                                 'source': 'IMAGE_BOX_NEAR_PATH_CONFIRMED'}
                        self.near_events[track.track_id] = (event, timestamp_ns)
                        events.append(event)
                    elif track.track_id in self.near_events:
                        event, _ = self.near_events[track.track_id]
                        held_event = dict(event)
                        held_event['bbox'] = list(track.box)
                        self.near_events[track.track_id] = (held_event, timestamp_ns)
                        events.append(held_event)
                else:
                    active_event = self.near_events.get(track.track_id)
                    if active_event is not None:
                        event, _ = active_event
                        clear_count = self.near_clear_confirmations.get(track.track_id, 0) + 1
                        if clear_count >= NEAR_OBJECT_CLEAR_OBSERVATIONS:
                            self.near_events.pop(track.track_id, None)
                            self.near_clear_confirmations.pop(track.track_id, None)
                        else:
                            self.near_clear_confirmations[track.track_id] = clear_count
                            held_event = dict(event)
                            held_event['bbox'] = list(track.box)
                            self.near_events[track.track_id] = (held_event, timestamp_ns)
                            events.append(held_event)
            previous_in_path = (len(history) >= 2
                                and self.inside(history[-2][1], history[-2][2]))
            entered_path = (trusted and len(history) >= 2 and track.name == 'person'
                            and info['in_assumed_path'] and not previous_in_path
                            and track.box[3] / height > .60
                            and abs(motion.dx) < .04 and abs(motion.dy) < .04
                            and abs(motion.rotation_dps) < 3.)
            if entered_path:
                # A transition from outside to inside is actionable image-space
                # evidence. A person first seen standing in the assumed path is
                # intentionally not treated as an event until motion/entry is
                # observed; this avoids a permanent roadside false alarm.
                events.append({'kind': 'PEDESTRIAN_IN_PATH', 'track_id': track.track_id,
                               'bbox': track.box, 'target_class': track.name,
                               'severity': 'warning',
                               'source': 'IMAGE_SPACE_PATH_ENTRY'})
            if trusted and len(history) >= 6:
                lateral, lateral_fit = trend(history, 1, corrected=True)
                expansion, expansion_fit = trend(history, 3)
                log_history = [tuple([*row[:3], math.log(row[3]), *row[4:]]) for row in history]
                log_growth_rate, _ = trend(log_history, 3)
                background_scale_rate, _ = trend(history, 5)
                residual_expansion = log_growth_rate-background_scale_rate
                growth = size/max(history[0][3], 1e-9)
                tau = size/expansion if expansion > 0 else None
                info.update(lateral_frame_widths_per_s=lateral, expansion_fit=expansion_fit,
                            visual_tau_s=tau, apparent_scale_growth=growth,
                            relative_log_expansion_per_s=residual_expansion)
                kind = None
                if (track is lead and foot > .57 and size > .035 and tau is not None
                        and tau < 2.5 and expansion_fit > .85 and growth > 1.25
                        and residual_expansion > .2 and abs(lateral) < .04):
                    kind = 'FRONT_COLLISION_RISK'
                if (track.name == 'person' and info['in_assumed_path'] and foot > .6
                        and abs(lateral) > .025 and lateral_fit > .7):
                    kind = 'PEDESTRIAN_CROSSING_PATH'
                if kind:
                    key = (track.track_id, kind)
                    count = self.confirmations.get(key, 0)+1
                    active_confirmations[key] = count
                    if count >= 2:
                        severity = 'critical' if kind == 'FRONT_COLLISION_RISK' else 'warning'
                        events.append({'kind': kind, 'track_id': track.track_id, 'bbox': track.box,
                                       'target_class': track.name, 'severity': severity,
                                       'source': 'IMAGE_TRAJECTORY_EXPERIMENTAL',
                                       'visual_tau_s': tau if kind == 'FRONT_COLLISION_RISK' else None})
                if (track.name in VEHICLES and foot > .57
                        and abs(lateral) > .03 and lateral_fit > .65):
                    previous_x = history[0][1]
                    current_x = history[-1][1]
                    toward_path = abs(current_x - .5) < abs(previous_x - .5)
                    entered_path = info['in_assumed_path'] and not previous_in_path
                    if abs(current_x - previous_x) > .04 and (toward_path or entered_path):
                        key = (track.track_id, 'VEHICLE_CUT_IN_CANDIDATE')
                        count = self.confirmations.get(key, 0) + 1
                        active_confirmations[key] = count
                        if count >= 2:
                            events.append({
                                'kind': 'VEHICLE_CUT_IN_CANDIDATE',
                                'track_id': track.track_id, 'bbox': track.box,
                                'target_class': track.name, 'severity': 'warning',
                                'lane_crossing': 'UNVERIFIED',
                                'source': 'IMAGE_LATERAL_TRAJECTORY_ONLY',
                                'lateral_frame_widths_per_s': lateral,
                            })
            # Continue a neutral lamp observation briefly when the previously
            # selected vehicle moves out of the assumed path. This grants no
            # collision/brake permission to an off-path vehicle.
            if trusted and track.track_id in self.recent_leads:
                lamp = paired_red_lamps(frame, track.box)
                track.lamp_history.append((timestamp_ns, lamp))
                before = [v for ts, v in track.lamp_history if .4 <= (timestamp_ns-ts)/1e9 <= 1.2]
                info['paired_red_lamp_fraction'] = lamp
                # Lamp appearance alone has no effect on the brake decision.
                if before and lamp > .025 and lamp-min(before) > .025:
                    info['brake_lamp_rise_candidate'] = True
                    key = (track.track_id, 'LEAD_BRAKE_LAMP_RISE')
                    count = self.confirmations.get(key, 0)+1
                    active_confirmations[key] = count
                    if count >= 2:
                        events.append({'kind': 'LEAD_BRAKE_LAMP_RISE', 'track_id': track.track_id,
                                       'bbox': track.box, 'source': 'UNCONFIRMED_PAIRED_RED_LAMP_APPEARANCE_CHANGE'})
                    if any(e['kind'] in ('FRONT_COLLISION_RISK', 'LEAD_RAPID_CLOSING')
                           and e['track_id'] == track.track_id for e in events):
                        events.append({'kind': 'SUSPECTED_BRAKING_WITH_CLOSING', 'track_id': track.track_id,
                                       'bbox': track.box, 'target_class': track.name,
                                       'severity': 'critical',
                                       'source': 'PAIRED_RED_LAMP_RISE_PLUS_IMAGE_EXPANSION'})
            evidence.append(info)
        for track_id, (event, seen_ns) in list(self.near_events.items()):
            if timestamp_ns - seen_ns > NEAR_OBJECT_HOLD_NS:
                self.near_events.pop(track_id, None)
                self.near_clear_confirmations.pop(track_id, None)
            elif track_id not in current_track_ids:
                events.append(event)
        self.confirmations = active_confirmations
        self.near_confirmations = active_near_confirmations
        self.observation = HazardObservation(timestamp_ns, tuple(events), tuple(evidence), self.path, motion,
                                             'tracking' if trusted else 'camera_motion_or_unconfirmed_background',
                                             lead.track_id if lead else None)
        self.timings.append((time.perf_counter()-started)*1000)
        return self.observation

    def current(self, now_ns):
        observed = self.observation
        if observed.timestamp_ns is None or not 0 <= now_ns-observed.timestamp_ns < 250_000_000:
            return HazardObservation(path=self.path, reason='observation_expired')
        return observed
